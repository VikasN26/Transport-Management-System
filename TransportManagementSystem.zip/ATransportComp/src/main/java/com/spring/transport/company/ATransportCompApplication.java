package com.spring.transport.company;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ATransportCompApplication {

	public static void main(String[] args) {
		SpringApplication.run(ATransportCompApplication.class, args);
	}

}
